# howtosteneros

**AdamW with a verified scout.** The main weights (`a1`) never take a raw optimizer step.
Instead a *scout* copy (`a2`) runs ahead with AdamW at its own adaptive learning rate, and `a1`
only slides toward it after the scout **beats `a1` on a fresh batch** (paired test).
When the scout fails, it is sent back to `a1`, its moments are reset, and its learning rate is cut.

> **Status: small-scale experiment (v0.1).** On two small tasks it matches a well-tuned AdamW.
> It is *not* shown to beat AdamW, and it has not been tested on large models.
> The PyTorch port is written but **untested** by the author — run `tests/test_torch.py` first.
> See [Honest results](#honest-results) before you use it.

## How it works

```
a1 = main weights (change only after a passed test)
a2 = scout (copy of a1)

repeat:
    a2 takes k AdamW steps                      # gradients computed AT a2
    test on ONE fresh batch, per-example losses of a1 and a2 (paired):
        success -> a1 <- a1 + alpha * (a2 - a1);  lr_a2 *= up
        failure -> a2 <- a1, AdamW moments = 0;   lr_a2 *= down
```

Options: `z` (accept only if the mean improvement is > z standard errors),
`lr_max` / `anneal_steps` (lr ceiling, optionally cosine-decayed),
`reset_on_accept` (Lookahead-style: scout restarts from `a1` after every success).

Related ideas you may know: [Lookahead](https://arxiv.org/abs/1907.08610) (slow/fast weights, but
no test), and trust-region / line-search methods (accept or reject a step by actual loss change).
This is a simple combination of those ideas, not a new class of optimizer.

## Install

```bash
pip install -e .            # NumPy core
pip install -e ".[torch]"   # + PyTorch port
```

## Usage (PyTorch)

```python
from howtosteneros import HowToSteneros

opt = HowToSteneros(model.parameters(), lr=1e-3, k=5, z=0.5)

for x, y in loader:
    opt.zero_grad(); F.cross_entropy(model(x), y).backward()
    opt.step()                                   # scout step (AdamW)
    if opt.ready():                              # every k steps
        xt, yt = next(test_iter)                 # fresh batch, same for a1 and a2
        opt.judge(lambda: F.cross_entropy(model(xt), yt, reduction="none"))

opt.load_main()                                  # put a1 into the model
```

Limitations of the PyTorch port: BatchNorm buffers are not tracked; the `judge` callable must return
per-example losses and should run the model in eval mode. Cost: about 2 extra forward passes on the
test batch every `k` steps.

NumPy version: `from howtosteneros import HowToStenerosNumpy` (see `benchmarks/bench2.py`).

## Honest results

Setup: MLP (NumPy), equal budget of gradient evaluations, hyperparameters of **both** methods tuned on
separate tuning seeds by validation loss, final numbers on 10 fresh test seeds (mean ± standard error).
Tasks: scikit-learn `digits`, and a noisy synthetic 6-class problem (15% label noise).

| Task | Metric | Tuned AdamW | HowToSteneros |
|---|---|---|---|
| digits | test accuracy | 97.44 ± 0.20 % | 97.40 ± 0.22 % |
| digits | test loss | 0.103 ± 0.012 | 0.116 ± 0.013 (slightly worse; paired diff +0.013, se 0.004) |
| noisy | test accuracy | 48.45 ± 0.46 % | 48.63 ± 0.52 % |
| noisy | test loss | 1.463 ± 0.015 | 1.425 ± 0.011 (slightly better; paired diff −0.038, se 0.009) |

**Takeaway: with a tuned learning rate, it is on par with AdamW, not better.**

### Bad starting learning rate (ablation)

Start lr = 0.1, which is far too high for these nets.

| Task | AdamW | AdamW, lr clamped to the cap | HowToSteneros, with lr cap | HowToSteneros, **no cap** |
|---|---|---|---|---|
| digits acc | 53.8 ± 3.6 % | 97.6 ± 0.2 % | 97.4 ± 0.2 % | 96.8 ± 0.2 % |
| noisy acc | 20.0 ± 1.7 % | 49.6 ± 0.4 % | 48.5 ± 0.5 % | 36.7 ± 2.4 % |

- The scout test does give real protection: **without any cap** it recovers from lr = 0.1
  (digits 96.8 % vs 53.8 % for plain AdamW), because failed scouts are discarded and the scout lr shrinks.
- But much of the benefit is simply an lr ceiling: AdamW clamped to the same ceiling does as well.
  On the noisy task, recovery without a cap is only partial (36.7 % vs ~49 %).
- On noisy data HowToSteneros with the cap has a much lower test loss (1.49 vs 2.34) than clamped AdamW,
  which has similar accuracy but is more over-confident. This is one observation on one task.

### Things I tried that did not help

* A third path `b1` that splits into two branches with different lrs and picks the best of three
  (equal gradient budget): no gain in accuracy, and worse recovery from a bad lr. Not included.

### What is not shown

Large models, transformers, long training, real-world datasets, memory/time overhead measurements.
The cost is real: 2 extra forward passes on the test batch every `k` steps plus a second copy of the
weights (and AdamW moments are kept for the scout).

## Reproduce

```bash
pip install -e ".[bench]"
python benchmarks/bench.py          # quick demo, ~20 s
python benchmarks/bench2.py         # full tuning + test protocol (~20-30 min on 2 cores)
python benchmarks/ablation_cap.py 0.1   # the bad-lr ablation above
python -m pytest tests              # NumPy tests (torch tests are skipped without torch)
```

## License

MIT.
