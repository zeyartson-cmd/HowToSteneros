import numpy as np

from howtosteneros.core import AdamW, HowToSteneros


def quad_grad(params, A, b):
    x = params[0]
    return [A @ x - b]


def quad_loss(x, A, b):
    return 0.5 * x @ A @ x - b @ x


def make(seed=0, d=10):
    rng = np.random.RandomState(seed)
    M = rng.randn(d, d)
    A = M @ M.T / d + 0.1 * np.eye(d)
    b = rng.randn(d)
    return A, b


def test_adamw_converges_on_quadratic():
    A, b = make()
    x = [np.zeros(10)]
    opt = AdamW(x, lr=0.05, weight_decay=0.0)
    for _ in range(2000):
        opt.step(x, quad_grad(x, A, b))
    assert np.linalg.norm(A @ x[0] - b) < 1e-2


def test_main_weights_only_change_on_accept():
    A, b = make()
    x = [np.zeros(10)]
    opt = HowToSteneros(x, lr=0.05, k=3, weight_decay=0.0)
    a1_before = x[0].copy()
    for _ in range(3):
        opt.step(quad_grad(opt.a2, A, b))
    assert np.allclose(opt.a1[0], a1_before)          # no test yet -> a1 untouched
    assert opt.ready()
    ok = opt.judge(np.array([1.0, 1.0]), np.array([2.0, 2.0]))   # scout worse
    assert not ok
    assert np.allclose(opt.a1[0], a1_before)          # rejected -> a1 unchanged
    assert np.allclose(opt.a2[0], opt.a1[0])          # scout sent back to a1


def test_accept_moves_a1_toward_a2():
    A, b = make()
    x = [np.zeros(10)]
    opt = HowToSteneros(x, lr=0.05, k=3, alpha=0.5, weight_decay=0.0)
    for _ in range(3):
        opt.step(quad_grad(opt.a2, A, b))
    a1_0, a2_0 = opt.a1[0].copy(), opt.a2[0].copy()
    ok = opt.judge(np.array([2.0, 2.0, 2.0]), np.array([1.0, 1.0, 1.0]))
    assert ok
    assert np.allclose(opt.a1[0], a1_0 + 0.5 * (a2_0 - a1_0))


def test_survives_absurd_lr():
    """With a huge starting lr the main weights must stay finite and improve."""
    A, b = make()
    x = [np.zeros(10)]
    opt = HowToSteneros(x, lr=5.0, k=3, lr_max=10.0, weight_decay=0.0)
    for _ in range(600):
        opt.step(quad_grad(opt.a2, A, b))
        if opt.ready():
            l1 = quad_loss(opt.a1[0], A, b)
            l2 = quad_loss(opt.a2[0], A, b)
            opt.judge(l1, l2)
    assert np.all(np.isfinite(opt.a1[0]))
    assert quad_loss(opt.a1[0], A, b) < quad_loss(np.zeros(10), A, b)
    assert opt.rejected > 0


def test_nan_scout_is_rejected():
    A, b = make()
    x = [np.zeros(10)]
    opt = HowToSteneros(x, lr=0.05, k=1)
    opt.step(quad_grad(opt.a2, A, b))
    assert not opt.judge(np.array([1.0, 1.0]), np.array([np.nan, 1.0]))
    assert np.all(np.isfinite(opt.a2[0]))
