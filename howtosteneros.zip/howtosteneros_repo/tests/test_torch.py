"""PyTorch port tests. Skipped automatically if torch is not installed.

The author could not run these in the environment where the code was written,
so please run them first:  pytest tests/test_torch.py
"""
import pytest

torch = pytest.importorskip("torch")

from howtosteneros.torch_optim import HowToSteneros  # noqa: E402


def make_problem(seed=0):
    g = torch.Generator().manual_seed(seed)
    X = torch.randn(256, 8, generator=g)
    w = torch.randn(8, generator=g)
    y = X @ w + 0.1 * torch.randn(256, generator=g)
    return X, y


def test_scout_step_matches_torch_adamw():
    """Without judge(), the scout path must equal torch.optim.AdamW."""
    X, y = make_problem()
    m1 = torch.nn.Linear(8, 1)
    m2 = torch.nn.Linear(8, 1)
    m2.load_state_dict(m1.state_dict())
    ref = torch.optim.AdamW(m1.parameters(), lr=1e-2, weight_decay=0.01)
    ours = HowToSteneros(m2.parameters(), lr=1e-2, weight_decay=0.01, k=10_000)
    for _ in range(25):
        for m, opt in ((m1, ref), (m2, ours)):
            opt.zero_grad()
            loss = ((m(X).squeeze(-1) - y) ** 2).mean()
            loss.backward()
            opt.step()
    for a, b in zip(m1.parameters(), m2.parameters()):
        assert torch.allclose(a, b, atol=1e-6)


def test_judge_accept_and_reject():
    X, y = make_problem()
    model = torch.nn.Linear(8, 1)
    opt = HowToSteneros(model.parameters(), lr=1e-2, k=3, alpha=0.5, weight_decay=0.0)
    a1_init = [p.detach().clone() for p in model.parameters()]
    for _ in range(3):
        opt.zero_grad()
        ((model(X).squeeze(-1) - y) ** 2).mean().backward()
        opt.step()
    assert opt.ready()
    scout = [p.detach().clone() for p in model.parameters()]
    fn = lambda: (model(X).squeeze(-1) - y) ** 2
    ok = opt.judge(fn)
    assert ok  # a few GD-like steps from init should help on this problem
    for p, a1_0, s in zip(model.parameters(), a1_init, scout):
        a1 = opt.state[p]["a1"]
        assert torch.allclose(a1, a1_0 + 0.5 * (s - a1_0), atol=1e-6)


def test_survives_absurd_lr():
    X, y = make_problem()
    model = torch.nn.Linear(8, 1)
    opt = HowToSteneros(model.parameters(), lr=5.0, lr_max=10.0, k=3, weight_decay=0.0)
    fn = lambda: (model(X).squeeze(-1) - y) ** 2
    start = fn().mean().item()
    for _ in range(300):
        opt.zero_grad()
        ((model(X).squeeze(-1) - y) ** 2).mean().backward()
        opt.step()
        if opt.ready():
            opt.judge(fn)
    opt.load_main()
    end = fn().mean().item()
    assert end == end and end < start  # finite and better than init
