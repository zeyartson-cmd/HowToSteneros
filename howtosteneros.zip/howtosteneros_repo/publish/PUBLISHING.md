# How to publish (about 15 minutes)

1. **Fill in the license name.** Replace `<YOUR NAME HERE>` in LICENSE.
2. **Run the PyTorch tests once** (they were not run by the author):
   `pip install -e ".[torch,dev]" && python -m pytest tests`
   If `test_scout_step_matches_torch_adamw` or another test fails, fix or tell people the port is broken.
   Optionally run `python examples/train_digits_torch.py`.
3. **GitHub** (best place for code): create repo `howtosteneros`, then
   `git init && git add . && git commit -m "Initial release" && git remote add origin <url> && git push -u origin main`
4. **Hugging Face** (optional): create a *model* repo `<you>/howtosteneros`, upload the same files; use
   `publish/hf_model_card_header.md` as the top of its README.md.
5. **Reddit**: use `publish/reddit_post.md`; replace `<GITHUB LINK>`. Read the subreddit rules for self-promotion first.
6. **PyPI** (optional, later): `python -m build && twine upload dist/*` once the torch tests pass.

Before posting, delete the `publish/` folder from the repo if you don't want it public.
