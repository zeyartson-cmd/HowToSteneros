# Reddit post draft (r/MachineLearning with the [P] flair, or r/learnmachinelearning for a softer audience)

**Title:**
[P] HowToSteneros: AdamW where the weights only move toward a scout that passed a paired test (on par with tuned AdamW on small tasks, looking for large-scale feedback)

**Body:**

I built a small experimental optimizer and I'd like feedback, especially from anyone who can test it on larger models.

**Idea.** Two copies of the weights. `a1` is the main copy. `a2` is a scout that runs ahead with AdamW at its own adaptive learning rate. Every k steps I compare `a1` and `a2` on one fresh batch (paired per-example losses). If the scout is better, `a1` slides toward it and the scout lr goes up. If not, the scout is sent back to `a1`, its Adam moments are reset and its lr goes down. So bad steps are filtered out before they reach the main weights.

I know it's close to Lookahead plus trust-region/line-search ideas. I'm not claiming a new optimizer class, just a simple combination I wanted to measure properly.

**Results (small MLPs, NumPy, equal gradient budget, both methods tuned on separate seeds, 10 fresh test seeds):**
- sklearn digits: 97.40 % vs 97.44 % for tuned AdamW (same within noise)
- noisy 6-class synthetic: 48.6 % vs 48.5 % (same), test loss slightly better (1.425 vs 1.463)
- Bad start lr = 0.1: plain AdamW collapses (54 % / 20 %). Without any lr cap, my method recovers on digits (96.8 %) but only partly on the noisy task (36.7 %). An lr ceiling alone also fixes AdamW, so much of the robustness is just the ceiling. I tested this ablation and it's in the README.

**What I'm NOT claiming:** that it beats AdamW with a tuned lr. It doesn't, in my tests. It also costs ~2 extra forward passes on the test batch every k steps and an extra copy of the weights.

**Things that didn't work:** a third "b1" path that splits into two branches with different lrs. No gain at equal gradient budget.

**Caveats:** only small tasks. The PyTorch port is written but I haven't been able to run it yet, so treat it as untested (tests included). BatchNorm buffers aren't handled.

Code + benchmark protocol + tests (MIT): <GITHUB LINK>

Questions I'd love opinions on: (1) is there prior work doing exactly this accept/reject on a scout copy? (2) would you expect the benefit to grow or vanish on large models / large batches? (3) better test statistics than a paired z-test on one batch?
