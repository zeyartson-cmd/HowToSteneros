"""
HowToSteneros (NumPy reference implementation).

Two sets of weights:
  a1 - main weights. They change only after a successful test.
  a2 - scout. Takes k AdamW steps with its own adaptive learning rate.

Loop:
  1. The scout (a2) takes k AdamW steps; gradients are computed AT a2.
  2. Test: losses of a1 and a2 on the same fresh batch (paired comparison).
  3. Success:  a1 <- a1 + alpha * (a2 - a1);  lr_a2 *= up.
     Failure:  a2 <- a1, AdamW moments reset;  lr_a2 *= down.

Options:
  z               - significance threshold: accept only if the mean per-example
                    improvement exceeds z standard errors (z=0: "just better").
  anneal_steps    - if set, the lr ceiling decays by cosine from lr_max to 0.
  reset_on_accept - after a success the scout is also moved back to a1
                    (Lookahead-style).
"""
import numpy as np


class AdamW:
    """Plain AdamW (decoupled weight decay). Params: list of numpy arrays, updated in place."""

    def __init__(self, params, lr=1e-3, betas=(0.9, 0.999), eps=1e-8, weight_decay=0.01):
        self.lr, self.b1, self.b2 = lr, betas[0], betas[1]
        self.eps, self.wd = eps, weight_decay
        self.m = [np.zeros_like(p) for p in params]
        self.v = [np.zeros_like(p) for p in params]
        self.t = 0

    def step(self, params, grads):
        self.t += 1
        c1 = 1.0 - self.b1 ** self.t
        c2 = 1.0 - self.b2 ** self.t
        for p, g, m, v in zip(params, grads, self.m, self.v):
            m *= self.b1
            m += (1.0 - self.b1) * g
            v *= self.b2
            v += (1.0 - self.b2) * g * g
            update = (m / c1) / (np.sqrt(v / c2) + self.eps)
            p -= self.lr * (update + self.wd * p)  # decoupled weight decay


class HowToSteneros:
    def __init__(self, params, lr=1e-3, k=5, alpha=0.5, up=1.1, down=0.5,
                 lr_min=1e-6, lr_max=1.0, z=0.0, anneal_steps=None,
                 reset_on_accept=False, betas=(0.9, 0.999), eps=1e-8,
                 weight_decay=0.01):
        self.a1 = params                              # main weights
        self.a2 = [p.copy() for p in params]          # scout
        self.inner = AdamW(self.a2, lr, betas, eps, weight_decay)
        self.lr_adapt = lr
        self.k, self.alpha, self.up, self.down = k, alpha, up, down
        self.lr_min, self.lr_max, self.z = lr_min, lr_max, z
        self.anneal_steps = anneal_steps
        self.reset_on_accept = reset_on_accept
        self._n = 0          # scout steps since the last test
        self._t = 0          # total steps
        self.accepted = 0
        self.rejected = 0

    @property
    def lr(self):
        return self.inner.lr

    def _cap(self):
        if self.anneal_steps is None:
            return self.lr_max
        frac = min(self._t / self.anneal_steps, 1.0)
        return self.lr_max * 0.5 * (1.0 + np.cos(np.pi * frac))

    def step(self, grads_at_a2):
        """One scout step. Gradients must be computed at the a2 point."""
        self.inner.lr = max(min(self.lr_adapt, self._cap()), 1e-12)
        self.inner.step(self.a2, grads_at_a2)
        self._n += 1
        self._t += 1

    def ready(self):
        return self._n >= self.k

    def _is_better(self, l1, l2):
        l1, l2 = np.asarray(l1, float), np.asarray(l2, float)
        if not np.all(np.isfinite(l2)):
            return False
        if l1.ndim == 0:                     # scalar losses
            return bool(l2 < l1)
        d = l1 - l2                          # paired differences: >0 means a2 is better
        se = d.std() / np.sqrt(len(d)) + 1e-12
        return bool(d.mean() > self.z * se and d.mean() > 0)

    def judge(self, loss_a1, loss_a2):
        """loss_a1/loss_a2: per-example losses on the test batch (or scalars)."""
        self._n = 0
        ok = self._is_better(loss_a1, loss_a2)
        if ok:
            for p1, p2 in zip(self.a1, self.a2):
                p1 += self.alpha * (p2 - p1)          # a1 slides toward a2
            if self.reset_on_accept:
                for p1, p2 in zip(self.a1, self.a2):
                    p2[...] = p1
            self.lr_adapt = min(self.lr_adapt * self.up, self.lr_max)
            self.accepted += 1
        else:
            for p1, p2 in zip(self.a1, self.a2):
                p2[...] = p1                          # scout returns to a1
            for m, v in zip(self.inner.m, self.inner.v):
                m[...] = 0.0
                v[...] = 0.0
            self.inner.t = 0
            self.lr_adapt = max(self.lr_adapt * self.down, self.lr_min)
            self.rejected += 1
        return ok
