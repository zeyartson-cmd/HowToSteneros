"""howtosteneros: AdamW with a verified scout (a1 = main weights, a2 = scout)."""
from .core import AdamW as NumpyAdamW
from .core import HowToSteneros as HowToStenerosNumpy

__version__ = "0.1.0"

try:
    from .torch_optim import HowToSteneros  # PyTorch optimizer (needs `pip install torch`)
except ModuleNotFoundError as _e:  # torch not installed
    if _e.name != "torch":
        raise

    class HowToSteneros:  # type: ignore[no-redef]
        def __init__(self, *a, **k):
            raise ImportError("HowToSteneros (PyTorch) needs torch: pip install torch. "
                              "The NumPy version is HowToStenerosNumpy.")

__all__ = ["HowToSteneros", "HowToStenerosNumpy", "NumpyAdamW"]
