"""
HowToSteneros for PyTorch.

Mirrors the tested NumPy implementation (howtosteneros.core). The scout step uses
torch._foreach_* ops (no per-tensor Python loop). Run tests/test_torch.py to verify.

How it differs from a normal optimizer
--------------------------------------
The model's parameters always hold the *scout* (a2). The main weights (a1) are
stored inside the optimizer. Every `k` steps you call `judge(...)`, which
compares a1 and a2 on the same fresh batch and either slides a1 toward a2
(success) or sends the scout back to a1 (failure).

    opt = HowToSteneros(model.parameters(), lr=1e-3, k=5)

    for step, (x, y) in enumerate(loader):
        loss = F.cross_entropy(model(x), y)
        opt.zero_grad(); loss.backward()
        opt.step()                        # scout takes an AdamW step
        if opt.ready():
            xt, yt = next(test_iter)      # a FRESH batch, same one for a1 and a2
            opt.judge(lambda: F.cross_entropy(model(xt), yt, reduction="none"))

    opt.load_main()                       # put the main weights (a1) into the model

Notes
-----
* The callable given to judge() must return a 1-D tensor of per-example losses
  (reduction="none"). It is called twice: once with the scout weights, once with
  a1. It is run under torch.no_grad().
* Only parameters are swapped. BatchNorm running statistics and other buffers
  are NOT tracked, so models with BatchNorm are not supported yet. Dropout
  should be disabled inside the callable (call model.eval() in it, then restore
  model.train()) for a clean comparison.
* Cost: one extra forward pass per judge() call for a1 and one for a2, i.e.
  about 2 forwards on the test batch every k steps.
"""
import math
from contextlib import contextmanager

import torch
from torch.optim import Optimizer


class HowToSteneros(Optimizer):
    def __init__(self, params, lr=1e-3, k=5, alpha=0.5, up=1.1, down=0.5,
                 lr_min=1e-6, lr_max=1.0, z=0.0, anneal_steps=None,
                 reset_on_accept=False, betas=(0.9, 0.999), eps=1e-8,
                 weight_decay=0.01):
        defaults = dict(lr=lr, betas=betas, eps=eps, weight_decay=weight_decay)
        super().__init__(params, defaults)
        self.k, self.alpha, self.up, self.down = k, alpha, up, down
        self.lr_min, self.lr_max, self.z = lr_min, lr_max, z
        self.anneal_steps, self.reset_on_accept = anneal_steps, reset_on_accept
        self.lr_adapt = lr
        self._n = 0          # scout steps since the last test
        self._t = 0          # total scout steps
        self.accepted = 0
        self.rejected = 0
        self._adam_t = 0
        for group in self.param_groups:
            for p in group["params"]:
                st = self.state[p]
                st["a1"] = p.detach().clone()
                st["m"] = torch.zeros_like(p)
                st["v"] = torch.zeros_like(p)

    # ---- scout step (AdamW with decoupled weight decay) ----
    def _cap(self):
        if self.anneal_steps is None:
            return self.lr_max
        frac = min(self._t / self.anneal_steps, 1.0)
        return self.lr_max * 0.5 * (1.0 + math.cos(math.pi * frac))

    @torch.no_grad()
    def step(self, closure=None):
        loss = None
        if closure is not None:
            with torch.enable_grad():
                loss = closure()
        lr = max(min(self.lr_adapt, self._cap()), 1e-12)
        self._adam_t += 1
        t = self._adam_t
        for group in self.param_groups:
            b1, b2 = group["betas"]
            ps, gs, ms, vs = [], [], [], []
            for p in group["params"]:
                if p.grad is None:
                    continue
                st = self.state[p]
                ps.append(p)
                gs.append(p.grad)
                ms.append(st["m"])
                vs.append(st["v"])
            if not ps:
                continue
            c1 = 1 - b1 ** t
            c2 = 1 - b2 ** t
            torch._foreach_mul_(ms, b1)
            torch._foreach_add_(ms, gs, alpha=1 - b1)
            torch._foreach_mul_(vs, b2)
            torch._foreach_addcmul_(vs, gs, gs, value=1 - b2)
            denom = torch._foreach_sqrt(vs)
            torch._foreach_div_(denom, math.sqrt(c2))
            torch._foreach_add_(denom, group["eps"])
            torch._foreach_mul_(ps, 1 - lr * group["weight_decay"])   # decoupled weight decay
            torch._foreach_addcdiv_(ps, ms, denom, value=-lr / c1)
        self._n += 1
        self._t += 1
        return loss

    def ready(self):
        return self._n >= self.k

    # ---- helpers ----
    def _params(self):
        return [p for g in self.param_groups for p in g["params"]]

    @torch.no_grad()
    def load_main(self):
        """Copy the main weights (a1) into the model. Use at the end of training."""
        for p in self._params():
            p.copy_(self.state[p]["a1"])

    def _swap(self):
        """Swap the storage of every parameter with a1 (no copy, no extra memory)."""
        for p in self._params():
            st = self.state[p]
            p.data, st["a1"] = st["a1"], p.data

    @contextmanager
    def main_weights(self):
        """Temporarily evaluate the model with a1 (the scout is restored on exit).

        Implemented as a swap of tensor storages, so it needs no extra memory.
        """
        self._swap()
        try:
            yield
        finally:
            self._swap()

    # ---- the test ----
    @torch.no_grad()
    def judge(self, per_example_loss_fn):
        """Compare scout (current model weights) with a1 on one batch.

        per_example_loss_fn() -> 1-D tensor of per-example losses.
        Returns True if the scout won (a1 slid toward it).
        """
        self._n = 0
        l2 = per_example_loss_fn().detach().float()
        with self.main_weights():
            l1 = per_example_loss_fn().detach().float()

        ok = False
        if torch.isfinite(l2).all():
            d = l1 - l2                              # >0 means the scout is better
            se = d.std(unbiased=True) / math.sqrt(d.numel()) + 1e-12
            ok = bool(d.mean() > 0 and d.mean() > self.z * se)

        for p in self._params():
            st = self.state[p]
            if ok:
                st["a1"].lerp_(p.detach(), self.alpha)    # a1 += alpha * (scout - a1)
                if self.reset_on_accept:
                    p.copy_(st["a1"])
            else:
                p.copy_(st["a1"])
                st["m"].zero_()
                st["v"].zero_()
                self._adam_t = 0
        if ok:
            self.lr_adapt = min(self.lr_adapt * self.up, self.lr_max)
            self.accepted += 1
        else:
            self.lr_adapt = max(self.lr_adapt * self.down, self.lr_min)
            self.rejected += 1
        return ok
