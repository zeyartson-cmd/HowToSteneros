"""
HowToSteneros for PyTorch.

!! STATUS: written to mirror the tested NumPy implementation (howtosteneros.core),
!! but this PyTorch port has NOT been run by its author. Run tests/test_torch.py
!! before trusting it.

How it differs from a normal optimizer
--------------------------------------
The model's parameters always hold the *scout* (a2). The main weights (a1) are
stored inside the optimizer. Every `k` steps you call `judge(...)`, which
compares a1 and a2 on the same fresh batch and either slides a1 toward a2
(success) or sends the scout back to a1 (failure).

    opt = HowToSteneros(model.parameters(), lr=1e-3, k=5)

    for step, (x, y) in enumerate(loader):
        loss = F.cross_entropy(model(x), y)
        opt.zero_grad(); loss.backward()
        opt.step()                        # scout takes an AdamW step
        if opt.ready():
            xt, yt = next(test_iter)      # a FRESH batch, same one for a1 and a2
            opt.judge(lambda: F.cross_entropy(model(xt), yt, reduction="none"))

    opt.load_main()                       # put the main weights (a1) into the model

Notes
-----
* The callable given to judge() must return a 1-D tensor of per-example losses
  (reduction="none"). It is called twice: once with the scout weights, once with
  a1. It is run under torch.no_grad().
* Only parameters are swapped. BatchNorm running statistics and other buffers
  are NOT tracked, so models with BatchNorm are not supported yet. Dropout
  should be disabled inside the callable (call model.eval() in it, then restore
  model.train()) for a clean comparison.
* Cost: one extra forward pass per judge() call for a1 and one for a2, i.e.
  about 2 forwards on the test batch every k steps.
"""
import math
from contextlib import contextmanager

import torch
from torch.optim import Optimizer


class HowToSteneros(Optimizer):
    def __init__(self, params, lr=1e-3, k=5, alpha=0.5, up=1.1, down=0.5,
                 lr_min=1e-6, lr_max=1.0, z=0.0, anneal_steps=None,
                 reset_on_accept=False, betas=(0.9, 0.999), eps=1e-8,
                 weight_decay=0.01):
        defaults = dict(lr=lr, betas=betas, eps=eps, weight_decay=weight_decay)
        super().__init__(params, defaults)
        self.k, self.alpha, self.up, self.down = k, alpha, up, down
        self.lr_min, self.lr_max, self.z = lr_min, lr_max, z
        self.anneal_steps, self.reset_on_accept = anneal_steps, reset_on_accept
        self.lr_adapt = lr
        self._n = 0          # scout steps since the last test
        self._t = 0          # total scout steps
        self.accepted = 0
        self.rejected = 0
        for group in self.param_groups:
            for p in group["params"]:
                st = self.state[p]
                st["a1"] = p.detach().clone()
                st["m"] = torch.zeros_like(p)
                st["v"] = torch.zeros_like(p)
                st["t"] = 0

    # ---- scout step (AdamW with decoupled weight decay) ----
    def _cap(self):
        if self.anneal_steps is None:
            return self.lr_max
        frac = min(self._t / self.anneal_steps, 1.0)
        return self.lr_max * 0.5 * (1.0 + math.cos(math.pi * frac))

    @torch.no_grad()
    def step(self, closure=None):
        loss = None
        if closure is not None:
            with torch.enable_grad():
                loss = closure()
        lr = max(min(self.lr_adapt, self._cap()), 1e-12)
        for group in self.param_groups:
            b1, b2 = group["betas"]
            for p in group["params"]:
                if p.grad is None:
                    continue
                st = self.state[p]
                st["t"] += 1
                st["m"].mul_(b1).add_(p.grad, alpha=1 - b1)
                st["v"].mul_(b2).addcmul_(p.grad, p.grad, value=1 - b2)
                c1 = 1 - b1 ** st["t"]
                c2 = 1 - b2 ** st["t"]
                denom = (st["v"] / c2).sqrt_().add_(group["eps"])
                update = (st["m"] / c1) / denom
                p.add_(update + group["weight_decay"] * p, alpha=-lr)
        self._n += 1
        self._t += 1
        return loss

    def ready(self):
        return self._n >= self.k

    # ---- helpers ----
    def _params(self):
        return [p for g in self.param_groups for p in g["params"]]

    @torch.no_grad()
    def load_main(self):
        """Copy the main weights (a1) into the model. Use at the end of training."""
        for p in self._params():
            p.copy_(self.state[p]["a1"])

    @contextmanager
    def main_weights(self):
        """Temporarily evaluate the model with a1 (the scout is restored on exit)."""
        ps = self._params()
        saved = [p.detach().clone() for p in ps]
        try:
            self.load_main()
            yield
        finally:
            with torch.no_grad():
                for p, s in zip(ps, saved):
                    p.copy_(s)

    # ---- the test ----
    @torch.no_grad()
    def judge(self, per_example_loss_fn):
        """Compare scout (current model weights) with a1 on one batch.

        per_example_loss_fn() -> 1-D tensor of per-example losses.
        Returns True if the scout won (a1 slid toward it).
        """
        self._n = 0
        l2 = per_example_loss_fn().detach().float()
        with self.main_weights():
            l1 = per_example_loss_fn().detach().float()

        ok = False
        if torch.isfinite(l2).all():
            d = l1 - l2                              # >0 means the scout is better
            se = d.std(unbiased=True) / math.sqrt(d.numel()) + 1e-12
            ok = bool(d.mean() > 0 and d.mean() > self.z * se)

        for p in self._params():
            st = self.state[p]
            if ok:
                st["a1"].add_(p.detach() - st["a1"], alpha=self.alpha)
                if self.reset_on_accept:
                    p.copy_(st["a1"])
            else:
                p.copy_(st["a1"])
                st["m"].zero_()
                st["v"].zero_()
                st["t"] = 0
        if ok:
            self.lr_adapt = min(self.lr_adapt * self.up, self.lr_max)
            self.accepted += 1
        else:
            self.lr_adapt = max(self.lr_adapt * self.down, self.lr_min)
            self.rejected += 1
        return ok
