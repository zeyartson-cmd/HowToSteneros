"""
GPU benchmark: memory, speed and quality of AdamW vs HowToSteneros.

Run it in a Colab GPU runtime (Runtime -> Change runtime type -> GPU):

    python benchmarks/gpu_bench.py --data cifar10 --width 2048 --depth 6 --steps 300

What it reports per method (and per learning rate):
  peak MiB   extra GPU memory used by the run (model + grads + optimizer states +
             activations), measured with torch.cuda.max_memory_allocated and
             excluding the dataset, which is kept on the GPU
  ms/step    wall-clock time per training step (including the judge() tests),
             measured after a warm-up, with cuda synchronize
  test acc / test loss    on held-out data, with the MAIN weights (a1) for HowToSteneros

Model: an MLP with LayerNorm (no BatchNorm, which the PyTorch port does not support).
Data: CIFAR-10 flattened (needs torchvision + internet) or a synthetic problem.
"""
import argparse
import gc
import time

import torch
import torch.nn as nn
import torch.nn.functional as F

from howtosteneros import HowToSteneros


def make_data(kind, device):
    if kind == "cifar10":
        import torchvision
        tr = torchvision.datasets.CIFAR10("/content/data", train=True, download=True)
        te = torchvision.datasets.CIFAR10("/content/data", train=False, download=True)
        Xtr = torch.from_numpy(tr.data).float().div(255).reshape(len(tr.data), -1)
        Xte = torch.from_numpy(te.data).float().div(255).reshape(len(te.data), -1)
        ytr, yte = torch.tensor(tr.targets), torch.tensor(te.targets)
        mu, sd = Xtr.mean(0), Xtr.std(0).clamp_min(0.05)
        Xtr, Xte = (Xtr - mu) / sd, (Xte - mu) / sd
    else:  # synthetic: noisy linear teacher on 3072 features, 10 classes
        g = torch.Generator().manual_seed(0)
        W = torch.randn(3072, 10, generator=g)
        Xtr = torch.randn(40000, 3072, generator=g)
        Xte = torch.randn(8000, 3072, generator=g)
        ytr = (Xtr @ W + 20 * torch.randn(40000, 10, generator=g)).argmax(1)
        yte = (Xte @ W + 20 * torch.randn(8000, 10, generator=g)).argmax(1)
    return [t.to(device) for t in (Xtr, ytr, Xte, yte)]


def make_model(width, depth, dim_in, classes=10):
    layers = [nn.Linear(dim_in, width), nn.LayerNorm(width), nn.GELU()]
    for _ in range(depth - 1):
        layers += [nn.Linear(width, width), nn.LayerNorm(width), nn.GELU()]
    layers += [nn.Linear(width, classes)]
    return nn.Sequential(*layers)


@torch.no_grad()
def evaluate(model, X, y):
    loss, correct = 0.0, 0
    for i in range(0, len(X), 2000):
        out = model(X[i:i + 2000]).float()
        loss += F.cross_entropy(out, y[i:i + 2000], reduction="sum").item()
        correct += (out.argmax(1) == y[i:i + 2000]).sum().item()
    return loss / len(X), correct / len(X)


def run_once(method, lr, seed, args, data, device):
    Xtr, ytr, Xte, yte = data
    gc.collect()
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats()
    base = torch.cuda.memory_allocated()

    torch.manual_seed(seed)
    model = make_model(args.width, args.depth, Xtr.shape[1]).to(device)
    n_params = sum(p.numel() for p in model.parameters())
    if method == "adamw":
        opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=0.01)
    else:
        opt = HowToSteneros(model.parameters(), lr=lr, k=int(method.split("_k")[1]),
                            z=args.z, lr_max=args.lr_max)

    g = torch.Generator().manual_seed(seed)
    total = args.steps + args.warmup
    for step in range(total):
        if step == args.warmup:
            torch.cuda.synchronize()
            t0 = time.time()
        idx = torch.randint(0, len(Xtr), (args.batch,), generator=g).to(device)
        x, y = Xtr[idx], ytr[idx]
        opt.zero_grad(set_to_none=True)
        F.cross_entropy(model(x), y).backward()
        opt.step()
        if method != "adamw" and opt.ready():
            tidx = torch.randint(0, len(Xtr), (args.tb,), generator=g).to(device)
            xt, yt = Xtr[tidx], ytr[tidx]
            opt.judge(lambda: F.cross_entropy(model(xt), yt, reduction="none"))
    torch.cuda.synchronize()
    ms_step = (time.time() - t0) / args.steps * 1000.0
    peak = (torch.cuda.max_memory_allocated() - base) / 2 ** 20

    if method != "adamw":
        opt.load_main()                       # evaluate the main weights a1
        rate = opt.accepted / max(1, opt.accepted + opt.rejected)
    else:
        rate = float("nan")
    te_loss, te_acc = evaluate(model, Xte, yte)
    del model, opt
    return dict(params=n_params / 1e6, peak=peak, ms=ms_step, loss=te_loss, acc=te_acc, rate=rate)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="cifar10", choices=["cifar10", "synthetic"])
    ap.add_argument("--width", type=int, default=2048)
    ap.add_argument("--depth", type=int, default=6)
    ap.add_argument("--steps", type=int, default=300)
    ap.add_argument("--warmup", type=int, default=20)
    ap.add_argument("--batch", type=int, default=128)
    ap.add_argument("--tb", type=int, default=128, help="test batch size for judge()")
    ap.add_argument("--lrs", default="1e-3,1e-2", help="comma separated learning rates")
    ap.add_argument("--ks", default="5,10", help="comma separated k values for HowToSteneros")
    ap.add_argument("--z", type=float, default=0.0)
    ap.add_argument("--lr_max", type=float, default=1.0)
    ap.add_argument("--seeds", type=int, default=2)
    args = ap.parse_args()

    assert torch.cuda.is_available(), "Use a GPU runtime (Runtime -> Change runtime type -> GPU)."
    device = "cuda"
    print("GPU:", torch.cuda.get_device_name(0))
    data = make_data(args.data, device)
    methods = ["adamw"] + [f"steneros_k{k}" for k in args.ks.split(",")]

    print(f"\n{'method':14s} {'lr':>7s} {'params':>8s} {'peak MiB':>9s} {'ms/step':>8s} "
          f"{'test acc':>9s} {'test loss':>10s} {'accept':>7s}")
    base_row = {}
    for lr in [float(x) for x in args.lrs.split(",")]:
        for m in methods:
            rs = [run_once(m, lr, s, args, data, device) for s in range(args.seeds)]
            avg = {k: sum(r[k] for r in rs) / len(rs) for k in rs[0]}
            if m == "adamw":
                base_row[lr] = avg
            ref = base_row.get(lr)
            extra = ""
            if ref and m != "adamw":
                extra = (f"   (mem {100 * (avg['peak'] / ref['peak'] - 1):+.0f}%, "
                         f"time {100 * (avg['ms'] / ref['ms'] - 1):+.0f}% vs AdamW)")
            print(f"{m:14s} {lr:7.0e} {avg['params']:7.1f}M {avg['peak']:9.0f} {avg['ms']:8.1f} "
                  f"{avg['acc']:9.4f} {avg['loss']:10.4f} {avg['rate']:7.0%}{extra}", flush=True)


if __name__ == "__main__":
    main()
