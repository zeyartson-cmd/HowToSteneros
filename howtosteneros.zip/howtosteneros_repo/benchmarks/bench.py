"""Quick comparison of AdamW and HowToSteneros on sklearn digits (NumPy MLP)."""
import json
import sys
import numpy as np
from sklearn.datasets import load_digits
from howtosteneros.core import AdamW, HowToSteneros

STEPS = 800        # gradient evaluations (same for all methods)
BATCH = 64
TEST_BATCH = 256   # fresh batch for the a1 vs a2 test
SEEDS = [0, 1, 2, 3, 4]
ADAMW_LRS = [1e-3, 3e-3, 1e-2, 3e-2, 1e-1]
SLIDE_LRS = [1e-3, 1e-2, 1e-1]


def load(seed):
    d = load_digits()
    X = d.data / 16.0
    y = d.target
    rng = np.random.RandomState(seed)
    idx = rng.permutation(len(X))
    n_tr = int(0.75 * len(X))
    tr, te = idx[:n_tr], idx[n_tr:]
    mu, sd = X[tr].mean(0), X[tr].std(0) + 1e-6
    X = (X - mu) / sd
    return X[tr], y[tr], X[te], y[te]


def init_params(rng, sizes=(64, 128, 64, 10)):
    params = []
    for i in range(len(sizes) - 1):
        W = rng.randn(sizes[i], sizes[i + 1]) * np.sqrt(2.0 / sizes[i])
        params += [W, np.zeros(sizes[i + 1])]
    return params


def forward(params, X):
    acts = [X]
    h = X
    n = len(params) // 2
    for i in range(n):
        h = h @ params[2 * i] + params[2 * i + 1]
        if i < n - 1:
            h = np.maximum(h, 0.0)
        acts.append(h)
    return acts


def softmax_ce(logits, y):
    z = logits - logits.max(1, keepdims=True)
    e = np.exp(z)
    p = e / e.sum(1, keepdims=True)
    loss = -np.log(p[np.arange(len(y)), y] + 1e-12).mean()
    return loss, p


def loss_only(params, X, y):
    with np.errstate(all="ignore"):
        loss, _ = softmax_ce(forward(params, X)[-1], y)
    return loss


def loss_grad(params, X, y):
    with np.errstate(all="ignore"):
        acts = forward(params, X)
        loss, p = softmax_ce(acts[-1], y)
        d = p.copy()
        d[np.arange(len(y)), y] -= 1.0
        d /= len(y)
        n = len(params) // 2
        grads = [None] * len(params)
        for i in reversed(range(n)):
            grads[2 * i] = acts[i].T @ d
            grads[2 * i + 1] = d.sum(0)
            if i > 0:
                d = d @ params[2 * i].T
                d = d * (acts[i] > 0)
    return loss, grads


def accuracy(params, X, y):
    with np.errstate(all="ignore"):
        return float((forward(params, X)[-1].argmax(1) == y).mean())


def run(method, lr, seed):
    Xtr, ytr, Xte, yte = load(seed)
    rng = np.random.RandomState(1000 + seed)
    params = init_params(rng)
    curve = []

    if method in ("adamw", "adamw_cos"):
        opt = AdamW(params, lr=lr)
        for t in range(1, STEPS + 1):
            if method == "adamw_cos":
                opt.lr = lr * 0.5 * (1.0 + np.cos(np.pi * (t - 1) / STEPS))
            b = rng.randint(0, len(Xtr), BATCH)
            _, g = loss_grad(params, Xtr[b], ytr[b])
            opt.step(params, g)
            if t % 50 == 0:
                curve.append((t, loss_only(params, Xte, yte)))
        main, extra = params, {}
    else:
        opt = HowToSteneros(params, lr=lr, k=5)
        for t in range(1, STEPS + 1):
            b = rng.randint(0, len(Xtr), BATCH)
            _, g = loss_grad(opt.a2, Xtr[b], ytr[b])   # gradient at a2
            opt.step(g)
            if opt.ready():
                tb = rng.randint(0, len(Xtr), TEST_BATCH)  # fresh batch
                opt.judge(loss_only(opt.a1, Xtr[tb], ytr[tb]),
                          loss_only(opt.a2, Xtr[tb], ytr[tb]))
            if t % 50 == 0:
                curve.append((t, loss_only(opt.a1, Xte, yte)))
        main = opt.a1
        extra = {"accepted": opt.accepted, "rejected": opt.rejected,
                 "final_lr_a2": opt.lr}

    te_loss = float(loss_only(main, Xte, yte))
    if not np.isfinite(te_loss):
        te_loss = float("inf")
    return {"test_loss": te_loss, "test_acc": accuracy(main, Xte, yte),
            "curve": curve, **extra}


def main():
    results = {}
    configs = ([("adamw", lr) for lr in ADAMW_LRS]
               + [("adamw_cos", lr) for lr in ADAMW_LRS]
               + [("slide", lr) for lr in SLIDE_LRS])
    for method, lr in configs:
        runs = [run(method, lr, s) for s in SEEDS]
        results[f"{method}@{lr:g}"] = runs
        acc = np.array([r["test_acc"] for r in runs])
        loss = np.array([r["test_loss"] for r in runs])
        extra = ""
        if method == "slide":
            acc_r = np.mean([r["accepted"] / (r["accepted"] + r["rejected"]) for r in runs])
            extra = f"  accepted={acc_r:.0%}  final_lr_a2~{np.mean([r['final_lr_a2'] for r in runs]):.1e}"
        print(f"{method:9s} lr={lr:<7g} acc={acc.mean():.4f}±{acc.std():.4f}  "
              f"loss={np.median(loss):.4f} (median){extra}", flush=True)
    with open("results.json", "w") as f:
        json.dump(results, f)


if __name__ == "__main__":
    main()
