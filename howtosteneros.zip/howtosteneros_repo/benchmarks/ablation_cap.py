"""Is the robustness to a bad starting lr due to the a1/a2 test, or just the lr_max cap?

Compares at a bad starting lr:
  AdamW (plain), AdamW with its lr clamped to the same cap,
  HowToSteneros with the cap (tuned config), HowToSteneros WITHOUT cap (lr_max=1).
"""
import sys
import numpy as np
from multiprocessing import Pool
import bench2
from bench2 import fmt, TEST_SEEDS

BEST = {
    "digits": ({'lr': 0.002, 'wd': 0.1, 'cos': False},
               {'lr': 0.001, 'lr_max': 0.01, 'up': 1.1, 'down': 0.85, 'alpha': 0.5, 'k': 3,
                'z': 0.0, 'tb': 256, 'anneal': True, 'reset': True, 'wd': 0.1}),
    "noisy": ({'lr': 0.001, 'wd': 0.1, 'cos': True},
              {'lr': 0.01, 'lr_max': 0.03, 'up': 1.1, 'down': 0.5, 'alpha': 0.8, 'k': 5,
               'z': 1.0, 'tb': 512, 'anneal': False, 'reset': True, 'wd': 0.1}),
}

if __name__ == "__main__":
    bad = float(sys.argv[1]) if len(sys.argv) > 1 else 0.1
    with Pool(2) as pool:
        for task, (ha, hs) in BEST.items():
            cap = hs["lr_max"]
            ev = lambda m, hp: pool.map(bench2.run, [(task, m, hp, s) for s in TEST_SEEDS])
            r = {
                "AdamW":                    ev("adamw", {**ha, "lr": bad}),
                f"AdamW clamped to {cap:g}": ev("adamw", {**ha, "lr": min(bad, cap)}),
                f"Steneros, cap {cap:g}":    ev("slide", {**hs, "lr": bad}),
                "Steneros, NO cap":          ev("slide", {**hs, "lr": bad, "lr_max": 1.0}),
            }
            print(f"\n{task}, starting lr={bad:g}")
            for k, v in r.items():
                print(f"  {k:24s} acc={fmt(v,'test_acc')}  loss={fmt(v,'test_loss')}")
