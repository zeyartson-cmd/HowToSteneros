"""
Fair GPU comparison: tuned AdamW (warmup + cosine decay + grad clipping) vs HowToSteneros.

Protocol
  * the last 5000 train images are a VALIDATION set; the learning rate of each method is
    picked by validation accuracy (seed 0), final numbers are on the real TEST set, seeds 1..N
  * equal number of gradient steps for both methods
  * both get gradient clipping; AdamW also gets warmup + cosine decay;
    HowToSteneros uses its own lr adaptation (optionally with the cosine ceiling)
Reports peak memory, ms/step, test accuracy mean +- std, and the paired difference.

    python benchmarks/gpu_fair.py --steps 600 --seeds 3
"""
import argparse, gc, math, os, sys, time
import torch
import torch.nn.functional as F
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from howtosteneros import HowToSteneros
from gpu_bench import make_data, make_model, evaluate


def run(method, lr, seed, a, data, Xval, yval, device):
    Xtr, ytr, Xte, yte = data
    gc.collect(); torch.cuda.empty_cache(); torch.cuda.reset_peak_memory_stats()
    base = torch.cuda.memory_allocated()
    torch.manual_seed(seed)
    model = make_model(a.width, a.depth, Xtr.shape[1]).to(device)
    total = a.steps
    if method == "adamw":
        opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=0.01)
    else:
        opt = HowToSteneros(model.parameters(), lr=lr, k=a.k, alpha=a.alpha, z=a.z, lr_max=lr * a.cap,
                            anneal_steps=total if a.anneal else None,
                            reset_on_accept=bool(a.reset))
    g = torch.Generator().manual_seed(seed)
    torch.cuda.synchronize(); t0 = time.time()
    for s in range(total):
        if method == "adamw":
            w = min(1.0, (s + 1) / a.warm)
            for pg in opt.param_groups:
                pg["lr"] = lr * w * 0.5 * (1 + math.cos(math.pi * s / total))
        idx = torch.randint(0, len(Xtr), (a.batch,), generator=g).to(device)
        opt.zero_grad(set_to_none=True)
        F.cross_entropy(model(Xtr[idx]), ytr[idx]).backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        if method != "adamw" and opt.ready():
            ti = torch.randint(0, len(Xtr), (a.tb,), generator=g).to(device)
            xt, yt = Xtr[ti], ytr[ti]
            opt.judge(lambda: F.cross_entropy(model(xt), yt, reduction="none"))
    torch.cuda.synchronize()
    ms = (time.time() - t0) / total * 1000
    peak = (torch.cuda.max_memory_allocated() - base) / 2 ** 20
    if method != "adamw":
        _, sc_acc = evaluate(model, Xte, yte)          # scout weights (a2)
        opt.load_main()
        if seed == 1:
            print(f"   [diag] accept rate {opt.accepted/max(1,opt.accepted+opt.rejected):.0%}, "
                  f"scout acc {sc_acc:.4f}", flush=True)
    _, vacc = evaluate(model, Xval, yval)
    _, tacc = evaluate(model, Xte, yte)
    del model, opt
    return vacc, tacc, ms, peak


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="cifar10")
    ap.add_argument("--width", type=int, default=1024)
    ap.add_argument("--depth", type=int, default=4)
    ap.add_argument("--steps", type=int, default=600)
    ap.add_argument("--warm", type=int, default=50)
    ap.add_argument("--batch", type=int, default=128)
    ap.add_argument("--tb", type=int, default=128)
    ap.add_argument("--z", type=float, default=0.0)
    ap.add_argument("--cap", type=float, default=1.0, help="lr_max = lr * cap (1 = never above start lr)")
    ap.add_argument("--anneal", type=int, default=1)
    ap.add_argument("--lrs", default="3e-4,1e-3,3e-3,1e-2")
    ap.add_argument("--k", type=int, default=5)
    ap.add_argument("--alpha", type=float, default=0.5)
    ap.add_argument("--reset", type=int, default=0)
    ap.add_argument("--seeds", type=int, default=3)
    a = ap.parse_args()
    device = "cuda"
    print("GPU:", torch.cuda.get_device_name(0))
    Xtr, ytr, Xte, yte = make_data(a.data, device)
    Xval, yval = Xtr[-5000:], ytr[-5000:]
    data = (Xtr[:-5000], ytr[:-5000], Xte, yte)
    lrs = [float(x) for x in a.lrs.split(",")]
    best = {}
    for m in ("adamw", "steneros"):
        sc = {lr: run(m, lr, 0, a, data, Xval, yval, device)[0] for lr in lrs}
        best[m] = max(sc, key=sc.get)
        print(f"{m:9s} val acc by lr: " + "  ".join(f"{lr:g}:{v:.3f}" for lr, v in sc.items()) + f"  -> pick {best[m]:g}", flush=True)
    res = {m: [run(m, best[m], s, a, data, Xval, yval, device) for s in range(1, a.seeds + 1)] for m in best}
    for m, r in res.items():
        t = torch.tensor([x[1] for x in r])
        print(f"{m:9s} lr={best[m]:g}  test acc {t.mean():.4f} +- {t.std():.4f}   "
              f"{sum(x[2] for x in r)/len(r):.1f} ms/step   peak {sum(x[3] for x in r)/len(r):.0f} MiB")
    d = torch.tensor([x[1] for x in res["steneros"]]) - torch.tensor([x[1] for x in res["adamw"]])
    print(f"paired diff (steneros - adamw) acc: {d.mean():+.4f}  per seed {[round(v,4) for v in d.tolist()]}")
    ra, rs = res["adamw"], res["steneros"]
    print(f"overhead: memory {100*(sum(x[3] for x in rs)/sum(x[3] for x in ra)-1):+.0f}%, "
          f"time {100*(sum(x[2] for x in rs)/sum(x[2] for x in ra)-1):+.0f}%")


if __name__ == "__main__":
    main()
