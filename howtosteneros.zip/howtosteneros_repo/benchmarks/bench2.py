"""
Fair comparison of AdamW and HowToSteneros.

Protocol:
  1. Hyperparameters of EACH method are tuned on tuning seeds (100-103) by
     VALIDATION loss, separately per task.
  2. The best configs are run on fresh test seeds (0-9); metrics are taken
     on a test split that tuning never saw.
  3. Equal budget: number of gradient evaluations (STEPS).
  4. Robustness test: same config but a bad starting learning rate.
"""
import json
import sys
from functools import lru_cache
from multiprocessing import Pool

import numpy as np
from sklearn.datasets import load_digits, make_classification

from bench import forward, init_params, loss_grad, accuracy
from howtosteneros.core import AdamW, HowToSteneros

TASKS = {
    "digits": {"steps": 800, "sizes": (64, 128, 64, 10)},
    "noisy": {"steps": 1200, "sizes": (40, 128, 64, 6)},
}
BATCH = 64
TUNE_SEEDS = [100, 101, 102, 103]
TEST_SEEDS = list(range(10))
N_SLIDE_CONFIGS = 48


@lru_cache(maxsize=None)
def raw_data(task):
    if task == "digits":
        d = load_digits()
        return d.data / 16.0, d.target
    X, y = make_classification(n_samples=3000, n_features=40, n_informative=12,
                               n_redundant=8, n_classes=6, n_clusters_per_class=2,
                               class_sep=0.8, flip_y=0.15, random_state=7)
    return X, y


def split(task, seed):
    X, y = raw_data(task)
    rng = np.random.RandomState(seed)
    idx = rng.permutation(len(X))
    n = len(X)
    tr, va, te = idx[:int(.6 * n)], idx[int(.6 * n):int(.75 * n)], idx[int(.75 * n):]
    mu, sd = X[tr].mean(0), X[tr].std(0)
    sd = np.maximum(sd, 0.05)  # do not blow up near-constant features
    Xn = (X - mu) / sd
    return Xn[tr], y[tr], Xn[va], y[va], Xn[te], y[te]


def loss_vec(params, X, y):
    with np.errstate(all="ignore"):
        z = forward(params, X)[-1]
        z = z - z.max(1, keepdims=True)
        lse = np.log(np.exp(z).sum(1))
        return lse - z[np.arange(len(y)), y]


def mean_loss(params, X, y):
    v = loss_vec(params, X, y).mean()
    return float(v) if np.isfinite(v) else float("inf")


def run(args):
    task, method, hp, seed = args
    cfg = TASKS[task]
    steps = cfg["steps"]
    Xtr, ytr, Xva, yva, Xte, yte = split(task, seed)
    rng = np.random.RandomState(1000 + seed)
    params = init_params(rng, cfg["sizes"])

    if method == "adamw":
        opt = AdamW(params, lr=hp["lr"], weight_decay=hp["wd"])
        for t in range(1, steps + 1):
            if hp.get("cos"):
                opt.lr = hp["lr"] * 0.5 * (1.0 + np.cos(np.pi * (t - 1) / steps))
            b = rng.randint(0, len(Xtr), BATCH)
            _, g = loss_grad(params, Xtr[b], ytr[b])
            opt.step(params, g)
        main, rate = params, None
    else:
        opt = HowToSteneros(params, lr=hp["lr"], k=hp["k"], alpha=hp["alpha"],
                         up=hp["up"], down=hp["down"], lr_max=hp["lr_max"],
                         z=hp["z"], reset_on_accept=hp["reset"],
                         anneal_steps=steps if hp["anneal"] else None,
                         weight_decay=hp["wd"])
        for t in range(1, steps + 1):
            b = rng.randint(0, len(Xtr), BATCH)
            _, g = loss_grad(opt.a2, Xtr[b], ytr[b])
            opt.step(g)
            if opt.ready():
                tb = rng.randint(0, len(Xtr), hp["tb"])
                opt.judge(loss_vec(opt.a1, Xtr[tb], ytr[tb]),
                          loss_vec(opt.a2, Xtr[tb], ytr[tb]))
        main = opt.a1
        rate = opt.accepted / max(1, opt.accepted + opt.rejected)

    return {"val_loss": mean_loss(main, Xva, yva), "val_acc": accuracy(main, Xva, yva),
            "test_loss": mean_loss(main, Xte, yte), "test_acc": accuracy(main, Xte, yte),
            "rate": rate}


def adamw_grid():
    return [{"lr": lr, "wd": wd, "cos": cos}
            for lr in (1e-3, 2e-3, 3e-3, 5e-3, 1e-2)
            for wd in (0.01, 0.05, 0.1)
            for cos in (False, True)]


def slide_space(n, rng):
    out = []
    for _ in range(n):
        out.append({
            "lr": float(rng.choice([1e-3, 3e-3, 1e-2])),
            "lr_max": float(rng.choice([1e-2, 3e-2, 1e-1])),
            "up": float(rng.choice([1.05, 1.1, 1.2])),
            "down": float(rng.choice([0.5, 0.7, 0.85])),
            "alpha": float(rng.choice([0.5, 0.8, 1.0])),
            "k": int(rng.choice([3, 5, 10])),
            "z": float(rng.choice([0.0, 0.5, 1.0])),
            "tb": int(rng.choice([128, 256, 512])),
            "anneal": bool(rng.choice([False, True])),
            "reset": bool(rng.choice([False, True])),
            "wd": float(rng.choice([0.01, 0.05, 0.1])),
        })
    return out


def tune(pool, task, method, configs):
    jobs = [(task, method, hp, s) for hp in configs for s in TUNE_SEEDS]
    res = pool.map(run, jobs)
    n = len(TUNE_SEEDS)
    scores = []
    for i, hp in enumerate(configs):
        r = res[i * n:(i + 1) * n]
        scores.append((float(np.mean([x["val_loss"] for x in r])),
                       float(np.mean([x["val_acc"] for x in r])), hp))
    scores.sort(key=lambda s: s[0])
    return scores


def evaluate(pool, task, method, hp):
    return pool.map(run, [(task, method, hp, s) for s in TEST_SEEDS])


def fmt(r, key):
    a = np.array([x[key] for x in r])
    return f"{a.mean():.4f}±{a.std(ddof=1) / np.sqrt(len(a)):.4f}"


def main():
    out = {}
    with Pool(2) as pool:
        for task in TASKS:
            print(f"\n=== {task} ===", flush=True)
            a_scores = tune(pool, task, "adamw", adamw_grid())
            s_scores = tune(pool, task, "slide",
                            slide_space(N_SLIDE_CONFIGS, np.random.RandomState(42)))
            best_a, best_s = a_scores[0][2], s_scores[0][2]
            print("AdamW best (val):", a_scores[0][:2], best_a)
            print("Slide best (val):", s_scores[0][:2], best_s, flush=True)

            ra = evaluate(pool, task, "adamw", best_a)
            rs = evaluate(pool, task, "slide", best_s)
            d_acc = np.array([s["test_acc"] - a["test_acc"] for a, s in zip(ra, rs)])
            d_loss = np.array([s["test_loss"] - a["test_loss"] for a, s in zip(ra, rs)])
            se = lambda d: d.std(ddof=1) / np.sqrt(len(d))
            print(f"TEST  AdamW: acc={fmt(ra, 'test_acc')}  loss={fmt(ra, 'test_loss')}")
            print(f"TEST  Slide: acc={fmt(rs, 'test_acc')}  loss={fmt(rs, 'test_loss')}  "
                  f"accept_rate={np.mean([x['rate'] for x in rs]):.0%}")
            print(f"PAIRED diff (Slide-AdamW): acc={d_acc.mean():+.4f} (se {se(d_acc):.4f}), "
                  f"loss={d_loss.mean():+.4f} (se {se(d_loss):.4f})")

            rob = {}
            for bad_lr in (3e-2, 1e-1):
                ra2 = evaluate(pool, task, "adamw", {**best_a, "lr": bad_lr})
                rs2 = evaluate(pool, task, "slide", {**best_s, "lr": bad_lr})
                rob[bad_lr] = (fmt(ra2, "test_acc"), fmt(rs2, "test_acc"))
                print(f"ROBUST start lr={bad_lr:g}: AdamW acc={rob[bad_lr][0]}  "
                      f"Slide acc={rob[bad_lr][1]}", flush=True)
            out[task] = {"adamw_best": best_a, "slide_best": best_s,
                         "adamw_test": ra, "slide_test": rs,
                         "d_acc": d_acc.tolist(), "d_loss": d_loss.tolist()}
    with open("results2.json", "w") as f:
        json.dump(out, f)


if __name__ == "__main__":
    main()
