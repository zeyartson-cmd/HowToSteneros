"""Minimal PyTorch example (needs torch + scikit-learn). Not run by the author."""
import numpy as np
import torch
import torch.nn.functional as F
from sklearn.datasets import load_digits

from howtosteneros import HowToSteneros

torch.manual_seed(0)
d = load_digits()
X = torch.tensor(d.data / 16.0, dtype=torch.float32)
y = torch.tensor(d.target)
perm = torch.randperm(len(X))
tr, te = perm[:1300], perm[1300:]
mu, sd = X[tr].mean(0), X[tr].std(0).clamp_min(0.05)
X = (X - mu) / sd

model = torch.nn.Sequential(torch.nn.Linear(64, 128), torch.nn.ReLU(),
                            torch.nn.Linear(128, 64), torch.nn.ReLU(),
                            torch.nn.Linear(64, 10))
opt = HowToSteneros(model.parameters(), lr=1e-3, k=5, z=0.5)

for step in range(800):
    b = tr[torch.randint(0, len(tr), (64,))]
    opt.zero_grad()
    F.cross_entropy(model(X[b]), y[b]).backward()
    opt.step()
    if opt.ready():
        tb = tr[torch.randint(0, len(tr), (256,))]          # fresh test batch
        opt.judge(lambda: F.cross_entropy(model(X[tb]), y[tb], reduction="none"))

opt.load_main()                                              # use the main weights
with torch.no_grad():
    acc = (model(X[te]).argmax(1) == y[te]).float().mean().item()
print(f"test acc {acc:.3f}  accepted={opt.accepted} rejected={opt.rejected}")
